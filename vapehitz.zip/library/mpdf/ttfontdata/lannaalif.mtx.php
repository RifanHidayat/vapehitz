<?php
$name='LannaAlif';
$type='TTF';
$desc=array (
  'CapHeight' => 714,
  'XHeight' => 495,
  'FontBBox' => '[-825 -542 1544 1111]',
  'Flags' => 4,
  'Ascent' => 1074,
  'Descent' => -537,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 640,
);
$unitsPerEm=2048;
$up=-106;
$ut=73;
$strp=259;
$strs=50;
$ttffile='D:/webroot/sidd/mpdf/ttfonts/lannaalif-v1-03.ttf';
$TTCfontID='0';
$originalsize=136648;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='lannaalif';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=true;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1074, -537, 150
// usWinAscent/usWinDescent = 1074, -537
// hhea Ascent/Descent/LineGap = 1074, -537, 33
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'latn' => 'DFLT zz01 ',
);
$GSUBFeatures=array (
  'latn' => 
  array (
    'DFLT' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
      ),
    ),
    'zz01' => 
    array (
      'zz01' => 
      array (
        0 => 0,
      ),
      'zz02' => 
      array (
        0 => 1,
      ),
      'zz03' => 
      array (
        0 => 2,
      ),
      'zz04' => 
      array (
        0 => 3,
      ),
      'zz05' => 
      array (
        0 => 4,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88186,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88742,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 89118,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 89150,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 89404,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'latn' => 'DFLT zz01 ',
);
$GPOSFeatures=array (
  'latn' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
      ),
      'mark' => 
      array (
        0 => 4,
        1 => 5,
      ),
      'mkmk' => 
      array (
        0 => 7,
      ),
    ),
    'zz01' => 
    array (
      'zz01' => 
      array (
        0 => 0,
      ),
      'zz02' => 
      array (
        0 => 1,
      ),
      'zz03' => 
      array (
        0 => 2,
      ),
      'zz04' => 
      array (
        0 => 3,
      ),
      'zz05' => 
      array (
        0 => 4,
      ),
      'zz06' => 
      array (
        0 => 5,
      ),
      'zz07' => 
      array (
        0 => 6,
      ),
      'zz08' => 
      array (
        0 => 7,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 86226,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 86484,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 86750,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 86812,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87538,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87582,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87742,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87774,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>