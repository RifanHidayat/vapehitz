<?php
$name='Pothana2000';
$type='TTF';
$desc=array (
  'CapHeight' => 880,
  'XHeight' => 0,
  'FontBBox' => '[-669 -814 1854 913]',
  'Flags' => 4,
  'Ascent' => 880,
  'Descent' => -814,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 618,
);
$unitsPerEm=1250;
$up=-880;
$ut=48;
$strp=258;
$strs=50;
$ttffile='D:/webroot/phpscript/pdf-watermarker-master/mpdf60/ttfonts/Pothana2000.ttf';
$TTCfontID='0';
$originalsize=194268;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='pothana2000';
$panose=' 0 0 0 0 4 0 0 0 0 0 0 0';
$haskerninfo=true;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 880, -840, 0
// usWinAscent/usWinDescent = 880, -840
// hhea Ascent/Descent/LineGap = 880, -840, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'telu' => 'DFLT ',
);
$GSUBFeatures=array (
  'telu' => 
  array (
    'DFLT' => 
    array (
      'akhn' => 
      array (
        0 => 0,
      ),
      'blwf' => 
      array (
        0 => 1,
      ),
      'blws' => 
      array (
        0 => 2,
        1 => 3,
        2 => 4,
        3 => 5,
        4 => 6,
        5 => 7,
        6 => 19,
        7 => 20,
        8 => 21,
      ),
      'abvs' => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
        3 => 11,
        4 => 12,
        5 => 13,
        6 => 14,
        7 => 15,
      ),
      'psts' => 
      array (
        0 => 16,
        1 => 17,
        2 => 22,
        3 => 23,
        4 => 24,
      ),
      'haln' => 
      array (
        0 => 18,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 186114,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 186298,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 186836,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 186968,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 187044,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 187136,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 187166,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 187406,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 256,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 187438,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 4,
    'Flag' => 512,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 187964,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 4,
    'Flag' => 768,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 188460,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 4,
    'Flag' => 1024,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 188956,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 1280,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 189452,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 4,
    'Flag' => 1536,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 189948,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 4,
    'Flag' => 1792,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 190474,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 4,
    'Flag' => 2048,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 191000,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 4,
    'Flag' => 2304,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 191526,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 192348,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 4,
    'Flag' => 2560,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 192372,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 192910,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 192998,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193100,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193142,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193344,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193400,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193450,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193464,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193492,
    ),
    'MarkFilteringSet' => '',
  ),
  28 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193506,
    ),
    'MarkFilteringSet' => '',
  ),
  29 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193520,
    ),
    'MarkFilteringSet' => '',
  ),
  30 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193538,
    ),
    'MarkFilteringSet' => '',
  ),
  31 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193566,
    ),
    'MarkFilteringSet' => '',
  ),
  32 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193580,
    ),
    'MarkFilteringSet' => '',
  ),
  33 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193608,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'deva' => 'DFLT ',
  'latn' => 'DFLT ',
  'telu' => 'DFLT ',
);
$GPOSFeatures=array (
  'telu' => 
  array (
    'DFLT' => 
    array (
      'blwm' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
        11 => 11,
        12 => 12,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 179010,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 179336,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 180504,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 181320,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 181834,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 182492,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 182874,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 182992,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 183520,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 183600,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 183962,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 184394,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 184568,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 184982,
    ),
    'MarkFilteringSet' => '',
  ),
);
$kerninfo=array (
  57438 => 
  array (
    57373 => -74,
    57380 => -80,
  ),
);
?>