<?php 
$originalsize=222632;
?>