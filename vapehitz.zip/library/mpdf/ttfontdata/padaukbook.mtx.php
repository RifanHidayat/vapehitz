<?php
$name='PadaukBook';
$type='TTF';
$desc=array (
  'CapHeight' => 933,
  'XHeight' => 448,
  'FontBBox' => '[-768 -486 2066 940]',
  'Flags' => 4,
  'Ascent' => 940,
  'Descent' => -486,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 567,
);
$unitsPerEm=1024;
$up=-415;
$ut=49;
$strp=256;
$strs=51;
$ttffile='D:/webroot/sidd/mpdf/ttfonts/Padauk-book.ttf';
$TTCfontID='0';
$originalsize=476528;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='padaukbook';
$panose=' 0 0 2 0 6 0 2 0 0 2 0 4';
$haskerninfo=false;
$haskernGPOS=true;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 986, -488, 0
// usWinAscent/usWinDescent = 986, -488
// hhea Ascent/Descent/LineGap = 986, -488, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'mymr' => 'DFLT KHT  KSW  KYU  dflt ',
);
$GSUBFeatures=array (
  'mymr' => 
  array (
    'DFLT' => 
    array (
      'clig' => 
      array (
        0 => 7,
        1 => 8,
        2 => 9,
        3 => 10,
        4 => 11,
        5 => 12,
        6 => 13,
        7 => 14,
        8 => 15,
        9 => 16,
        10 => 17,
        11 => 18,
        12 => 19,
        13 => 20,
        14 => 21,
        15 => 22,
        16 => 23,
        17 => 24,
        18 => 25,
        19 => 26,
        20 => 27,
        21 => 28,
        22 => 29,
        23 => 30,
        24 => 31,
        25 => 32,
        26 => 33,
        27 => 34,
        28 => 35,
        29 => 36,
        30 => 37,
        31 => 38,
        32 => 39,
        33 => 40,
        34 => 41,
        35 => 42,
        36 => 43,
        37 => 44,
        38 => 45,
        39 => 46,
        40 => 47,
        41 => 48,
        42 => 49,
        43 => 50,
        44 => 51,
        45 => 52,
        46 => 53,
        47 => 54,
        48 => 55,
        49 => 56,
        50 => 57,
        51 => 58,
        52 => 59,
        53 => 60,
        54 => 61,
        55 => 62,
        56 => 63,
        57 => 72,
        58 => 71,
        59 => 64,
        60 => 65,
        61 => 66,
        62 => 67,
        63 => 68,
        64 => 69,
        65 => 70,
        66 => 73,
        67 => 74,
        68 => 75,
        69 => 76,
        70 => 77,
        71 => 78,
        72 => 79,
        73 => 80,
        74 => 81,
        75 => 82,
        76 => 83,
        77 => 84,
        78 => 85,
        79 => 86,
        80 => 87,
        81 => 89,
        82 => 88,
        83 => 90,
        84 => 91,
        85 => 92,
        86 => 93,
        87 => 94,
        88 => 95,
        89 => 96,
        90 => 97,
      ),
    ),
    'KHT ' => 
    array (
      'clig' => 
      array (
        0 => 7,
        1 => 8,
        2 => 9,
        3 => 10,
        4 => 11,
        5 => 12,
        6 => 13,
        7 => 14,
        8 => 15,
        9 => 16,
        10 => 17,
        11 => 18,
        12 => 19,
        13 => 20,
        14 => 21,
        15 => 22,
        16 => 23,
        17 => 24,
        18 => 25,
        19 => 26,
        20 => 27,
        21 => 28,
        22 => 29,
        23 => 30,
        24 => 31,
        25 => 32,
        26 => 33,
        27 => 34,
        28 => 35,
        29 => 36,
        30 => 37,
        31 => 38,
        32 => 39,
        33 => 40,
        34 => 41,
        35 => 42,
        36 => 43,
        37 => 44,
        38 => 45,
        39 => 46,
        40 => 47,
        41 => 48,
        42 => 49,
        43 => 50,
        44 => 51,
        45 => 52,
        46 => 53,
        47 => 54,
        48 => 55,
        49 => 56,
        50 => 57,
        51 => 58,
        52 => 59,
        53 => 60,
        54 => 61,
        55 => 62,
        56 => 63,
        57 => 72,
        58 => 71,
        59 => 64,
        60 => 65,
        61 => 66,
        62 => 67,
        63 => 68,
        64 => 69,
        65 => 70,
        66 => 73,
        67 => 74,
        68 => 75,
        69 => 76,
        70 => 77,
        71 => 78,
        72 => 79,
        73 => 80,
        74 => 81,
        75 => 82,
        76 => 83,
        77 => 84,
        78 => 85,
        79 => 86,
        80 => 87,
        81 => 89,
        82 => 88,
        83 => 90,
        84 => 91,
        85 => 92,
        86 => 93,
        87 => 94,
        88 => 95,
        89 => 96,
        90 => 97,
        91 => 98,
        92 => 99,
      ),
    ),
    'KSW ' => 
    array (
      'clig' => 
      array (
        0 => 7,
        1 => 8,
        2 => 9,
        3 => 10,
        4 => 11,
        5 => 12,
        6 => 13,
        7 => 14,
        8 => 15,
        9 => 16,
        10 => 17,
        11 => 18,
        12 => 19,
        13 => 20,
        14 => 21,
        15 => 22,
        16 => 23,
        17 => 24,
        18 => 25,
        19 => 26,
        20 => 27,
        21 => 28,
        22 => 29,
        23 => 30,
        24 => 31,
        25 => 32,
        26 => 33,
        27 => 34,
        28 => 35,
        29 => 36,
        30 => 37,
        31 => 38,
        32 => 39,
        33 => 40,
        34 => 41,
        35 => 42,
        36 => 43,
        37 => 44,
        38 => 45,
        39 => 46,
        40 => 47,
        41 => 48,
        42 => 49,
        43 => 50,
        44 => 51,
        45 => 52,
        46 => 53,
        47 => 54,
        48 => 55,
        49 => 56,
        50 => 57,
        51 => 58,
        52 => 59,
        53 => 60,
        54 => 61,
        55 => 62,
        56 => 63,
        57 => 72,
        58 => 71,
        59 => 64,
        60 => 65,
        61 => 66,
        62 => 67,
        63 => 68,
        64 => 69,
        65 => 70,
        66 => 73,
        67 => 74,
        68 => 75,
        69 => 76,
        70 => 77,
        71 => 78,
        72 => 79,
        73 => 80,
        74 => 81,
        75 => 82,
        76 => 83,
        77 => 84,
        78 => 85,
        79 => 86,
        80 => 87,
        81 => 89,
        82 => 88,
        83 => 90,
        84 => 91,
        85 => 92,
        86 => 93,
        87 => 94,
        88 => 95,
        89 => 96,
        90 => 97,
        91 => 102,
        92 => 100,
      ),
    ),
    'KYU ' => 
    array (
      'clig' => 
      array (
        0 => 7,
        1 => 8,
        2 => 9,
        3 => 10,
        4 => 11,
        5 => 12,
        6 => 13,
        7 => 14,
        8 => 15,
        9 => 16,
        10 => 17,
        11 => 18,
        12 => 19,
        13 => 20,
        14 => 21,
        15 => 22,
        16 => 23,
        17 => 24,
        18 => 25,
        19 => 26,
        20 => 27,
        21 => 28,
        22 => 29,
        23 => 30,
        24 => 31,
        25 => 32,
        26 => 33,
        27 => 34,
        28 => 35,
        29 => 36,
        30 => 37,
        31 => 38,
        32 => 39,
        33 => 40,
        34 => 41,
        35 => 42,
        36 => 43,
        37 => 44,
        38 => 45,
        39 => 46,
        40 => 47,
        41 => 48,
        42 => 49,
        43 => 50,
        44 => 51,
        45 => 52,
        46 => 53,
        47 => 54,
        48 => 55,
        49 => 56,
        50 => 57,
        51 => 58,
        52 => 59,
        53 => 60,
        54 => 61,
        55 => 62,
        56 => 63,
        57 => 72,
        58 => 71,
        59 => 64,
        60 => 65,
        61 => 66,
        62 => 67,
        63 => 68,
        64 => 69,
        65 => 70,
        66 => 73,
        67 => 74,
        68 => 75,
        69 => 76,
        70 => 77,
        71 => 78,
        72 => 79,
        73 => 80,
        74 => 81,
        75 => 82,
        76 => 83,
        77 => 84,
        78 => 85,
        79 => 86,
        80 => 87,
        81 => 89,
        82 => 88,
        83 => 90,
        84 => 91,
        85 => 92,
        86 => 93,
        87 => 94,
        88 => 95,
        89 => 96,
        90 => 97,
        91 => 101,
        92 => 100,
      ),
    ),
    'dflt' => 
    array (
      'clig' => 
      array (
        0 => 7,
        1 => 8,
        2 => 9,
        3 => 10,
        4 => 11,
        5 => 12,
        6 => 13,
        7 => 14,
        8 => 15,
        9 => 16,
        10 => 17,
        11 => 18,
        12 => 19,
        13 => 20,
        14 => 21,
        15 => 22,
        16 => 23,
        17 => 24,
        18 => 25,
        19 => 26,
        20 => 27,
        21 => 28,
        22 => 29,
        23 => 30,
        24 => 31,
        25 => 32,
        26 => 33,
        27 => 34,
        28 => 35,
        29 => 36,
        30 => 37,
        31 => 38,
        32 => 39,
        33 => 40,
        34 => 41,
        35 => 42,
        36 => 43,
        37 => 44,
        38 => 45,
        39 => 46,
        40 => 47,
        41 => 48,
        42 => 49,
        43 => 50,
        44 => 51,
        45 => 52,
        46 => 53,
        47 => 54,
        48 => 55,
        49 => 56,
        50 => 57,
        51 => 58,
        52 => 59,
        53 => 60,
        54 => 61,
        55 => 62,
        56 => 63,
        57 => 72,
        58 => 71,
        59 => 64,
        60 => 65,
        61 => 66,
        62 => 67,
        63 => 68,
        64 => 69,
        65 => 70,
        66 => 73,
        67 => 74,
        68 => 75,
        69 => 76,
        70 => 77,
        71 => 78,
        72 => 79,
        73 => 80,
        74 => 81,
        75 => 82,
        76 => 83,
        77 => 84,
        78 => 85,
        79 => 86,
        80 => 87,
        81 => 89,
        82 => 88,
        83 => 90,
        84 => 91,
        85 => 92,
        86 => 93,
        87 => 94,
        88 => 95,
        89 => 96,
        90 => 97,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 19764,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 19786,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 19956,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 19978,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 20140,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 20178,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 20204,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 20230,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 20296,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 10,
    'Subtables' => 
    array (
      0 => 20882,
      1 => 20906,
      2 => 20930,
      3 => 20954,
      4 => 20974,
      5 => 20994,
      6 => 21014,
      7 => 21034,
      8 => 21054,
      9 => 21074,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 6,
    'Subtables' => 
    array (
      0 => 21412,
      1 => 21434,
      2 => 21456,
      3 => 21478,
      4 => 21498,
      5 => 21518,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 21784,
      1 => 21804,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 22082,
      1 => 22102,
      2 => 22124,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 22404,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 22682,
      1 => 22702,
      2 => 22722,
      3 => 22742,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 23034,
      1 => 23054,
      2 => 23074,
      3 => 23094,
      4 => 23114,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 7,
    'Subtables' => 
    array (
      0 => 23424,
      1 => 23444,
      2 => 23464,
      3 => 23484,
      4 => 23504,
      5 => 23524,
      6 => 23544,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 11,
    'Subtables' => 
    array (
      0 => 23874,
      1 => 23894,
      2 => 23914,
      3 => 23934,
      4 => 23956,
      5 => 23976,
      6 => 23996,
      7 => 24016,
      8 => 24036,
      9 => 24056,
      10 => 24076,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 9,
    'Subtables' => 
    array (
      0 => 24466,
      1 => 24486,
      2 => 24506,
      3 => 24526,
      4 => 24546,
      5 => 24566,
      6 => 24586,
      7 => 24606,
      8 => 24626,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 16,
    'Subtables' => 
    array (
      0 => 25008,
      1 => 25028,
      2 => 25048,
      3 => 25070,
      4 => 25090,
      5 => 25110,
      6 => 25130,
      7 => 25150,
      8 => 25170,
      9 => 25190,
      10 => 25210,
      11 => 25230,
      12 => 25250,
      13 => 25270,
      14 => 25290,
      15 => 25310,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 11,
    'Subtables' => 
    array (
      0 => 25740,
      1 => 25760,
      2 => 25780,
      3 => 25800,
      4 => 25820,
      5 => 25840,
      6 => 25860,
      7 => 25880,
      8 => 25900,
      9 => 25920,
      10 => 25940,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 27,
    'Subtables' => 
    array (
      0 => 26366,
      1 => 26386,
      2 => 26408,
      3 => 26430,
      4 => 26452,
      5 => 26472,
      6 => 26492,
      7 => 26512,
      8 => 26532,
      9 => 26552,
      10 => 26572,
      11 => 26592,
      12 => 26612,
      13 => 26632,
      14 => 26652,
      15 => 26672,
      16 => 26692,
      17 => 26712,
      18 => 26732,
      19 => 26752,
      20 => 26772,
      21 => 26792,
      22 => 26812,
      23 => 26832,
      24 => 26854,
      25 => 26876,
      26 => 26896,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 27336,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 23,
    'Subtables' => 
    array (
      0 => 27436,
      1 => 27456,
      2 => 27476,
      3 => 27496,
      4 => 27516,
      5 => 27536,
      6 => 27556,
      7 => 27576,
      8 => 27596,
      9 => 27616,
      10 => 27636,
      11 => 27656,
      12 => 27676,
      13 => 27696,
      14 => 27716,
      15 => 27736,
      16 => 27756,
      17 => 27776,
      18 => 27796,
      19 => 27816,
      20 => 27836,
      21 => 27856,
      22 => 27876,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 28352,
      1 => 28372,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 28646,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 28958,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 28986,
    ),
    'MarkFilteringSet' => '',
  ),
  28 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 29032,
    ),
    'MarkFilteringSet' => '',
  ),
  29 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 29406,
      1 => 29426,
      2 => 29446,
      3 => 29468,
    ),
    'MarkFilteringSet' => '',
  ),
  30 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 29690,
    ),
    'MarkFilteringSet' => '',
  ),
  31 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 29728,
    ),
    'MarkFilteringSet' => '',
  ),
  32 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 29990,
      1 => 30012,
    ),
    'MarkFilteringSet' => '',
  ),
  33 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 30306,
      1 => 30328,
    ),
    'MarkFilteringSet' => '',
  ),
  34 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 30626,
      1 => 30650,
      2 => 30676,
      3 => 30700,
    ),
    'MarkFilteringSet' => '',
  ),
  35 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 31008,
    ),
    'MarkFilteringSet' => '',
  ),
  36 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 31292,
    ),
    'MarkFilteringSet' => '',
  ),
  37 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 31578,
      1 => 31602,
    ),
    'MarkFilteringSet' => '',
  ),
  38 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 31902,
    ),
    'MarkFilteringSet' => '',
  ),
  39 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 32168,
    ),
    'MarkFilteringSet' => '',
  ),
  40 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 32436,
      1 => 32458,
    ),
    'MarkFilteringSet' => '',
  ),
  41 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 32742,
      1 => 32760,
    ),
    'MarkFilteringSet' => '',
  ),
  42 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 32812,
    ),
    'MarkFilteringSet' => '',
  ),
  43 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 8,
    'Subtables' => 
    array (
      0 => 32872,
      1 => 32890,
      2 => 32908,
      3 => 32928,
      4 => 32948,
      5 => 32968,
      6 => 32986,
      7 => 33006,
    ),
    'MarkFilteringSet' => '',
  ),
  44 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 7,
    'Subtables' => 
    array (
      0 => 33304,
      1 => 33322,
      2 => 33342,
      3 => 33362,
      4 => 33382,
      5 => 33404,
      6 => 33424,
    ),
    'MarkFilteringSet' => '',
  ),
  45 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 33720,
    ),
    'MarkFilteringSet' => '',
  ),
  46 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 33912,
      1 => 33930,
    ),
    'MarkFilteringSet' => '',
  ),
  47 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 34132,
      1 => 34150,
      2 => 34170,
    ),
    'MarkFilteringSet' => '',
  ),
  48 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 34534,
      1 => 34552,
    ),
    'MarkFilteringSet' => '',
  ),
  49 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 14,
    'Subtables' => 
    array (
      0 => 34696,
      1 => 34714,
      2 => 34736,
      3 => 34756,
      4 => 34776,
      5 => 34796,
      6 => 34816,
      7 => 34836,
      8 => 34856,
      9 => 34876,
      10 => 34896,
      11 => 34918,
      12 => 34940,
      13 => 34962,
    ),
    'MarkFilteringSet' => '',
  ),
  50 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 8,
    'Subtables' => 
    array (
      0 => 35416,
      1 => 35436,
      2 => 35456,
      3 => 35476,
      4 => 35496,
      5 => 35516,
      6 => 35536,
      7 => 35556,
    ),
    'MarkFilteringSet' => '',
  ),
  51 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 35648,
      1 => 35668,
      2 => 35688,
    ),
    'MarkFilteringSet' => '',
  ),
  52 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 35746,
    ),
    'MarkFilteringSet' => '',
  ),
  53 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 35792,
    ),
    'MarkFilteringSet' => '',
  ),
  54 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 9,
    'Subtables' => 
    array (
      0 => 35922,
      1 => 35940,
      2 => 35960,
      3 => 35978,
      4 => 35996,
      5 => 36014,
      6 => 36032,
      7 => 36050,
      8 => 36068,
    ),
    'MarkFilteringSet' => '',
  ),
  55 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 36346,
      1 => 36364,
      2 => 36382,
      3 => 36402,
    ),
    'MarkFilteringSet' => '',
  ),
  56 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 36578,
    ),
    'MarkFilteringSet' => '',
  ),
  57 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 36622,
      1 => 36640,
      2 => 36660,
    ),
    'MarkFilteringSet' => '',
  ),
  58 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 36786,
      1 => 36806,
    ),
    'MarkFilteringSet' => '',
  ),
  59 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 36884,
      1 => 36908,
      2 => 36934,
      3 => 36960,
      4 => 36986,
    ),
    'MarkFilteringSet' => '',
  ),
  60 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 37380,
    ),
    'MarkFilteringSet' => '',
  ),
  61 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 37652,
      1 => 37676,
      2 => 37700,
    ),
    'MarkFilteringSet' => '',
  ),
  62 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 38014,
    ),
    'MarkFilteringSet' => '',
  ),
  63 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 38300,
    ),
    'MarkFilteringSet' => '',
  ),
  64 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 38576,
    ),
    'MarkFilteringSet' => '',
  ),
  65 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 38852,
    ),
    'MarkFilteringSet' => '',
  ),
  66 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 39128,
    ),
    'MarkFilteringSet' => '',
  ),
  67 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 39404,
    ),
    'MarkFilteringSet' => '',
  ),
  68 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 39680,
    ),
    'MarkFilteringSet' => '',
  ),
  69 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 39960,
      1 => 39986,
      2 => 40012,
    ),
    'MarkFilteringSet' => '',
  ),
  70 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 40398,
      1 => 40422,
    ),
    'MarkFilteringSet' => '',
  ),
  71 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 40796,
    ),
    'MarkFilteringSet' => '',
  ),
  72 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 41170,
    ),
    'MarkFilteringSet' => '',
  ),
  73 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 6,
    'Subtables' => 
    array (
      0 => 41464,
      1 => 41488,
      2 => 41512,
      3 => 41536,
      4 => 41560,
      5 => 41584,
    ),
    'MarkFilteringSet' => '',
  ),
  74 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 41914,
    ),
    'MarkFilteringSet' => '',
  ),
  75 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 42184,
    ),
    'MarkFilteringSet' => '',
  ),
  76 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 42462,
    ),
    'MarkFilteringSet' => '',
  ),
  77 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 42750,
    ),
    'MarkFilteringSet' => '',
  ),
  78 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 43048,
    ),
    'MarkFilteringSet' => '',
  ),
  79 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 43348,
    ),
    'MarkFilteringSet' => '',
  ),
  80 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 43658,
      1 => 43686,
    ),
    'MarkFilteringSet' => '',
  ),
  81 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 43994,
    ),
    'MarkFilteringSet' => '',
  ),
  82 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 44290,
    ),
    'MarkFilteringSet' => '',
  ),
  83 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 10,
    'Subtables' => 
    array (
      0 => 44684,
      1 => 44704,
      2 => 44726,
      3 => 44748,
      4 => 44770,
      5 => 44792,
      6 => 44814,
      7 => 44836,
      8 => 44860,
      9 => 44882,
    ),
    'MarkFilteringSet' => '',
  ),
  84 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 45270,
    ),
    'MarkFilteringSet' => '',
  ),
  85 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 45382,
      1 => 45402,
    ),
    'MarkFilteringSet' => '',
  ),
  86 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 45546,
    ),
    'MarkFilteringSet' => '',
  ),
  87 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 45612,
      1 => 45632,
    ),
    'MarkFilteringSet' => '',
  ),
  88 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 45776,
      1 => 45796,
    ),
    'MarkFilteringSet' => '',
  ),
  89 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 45946,
      1 => 45966,
      2 => 45986,
      3 => 46006,
    ),
    'MarkFilteringSet' => '',
  ),
  90 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 46084,
    ),
    'MarkFilteringSet' => '',
  ),
  91 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 10,
    'Subtables' => 
    array (
      0 => 46166,
      1 => 46186,
      2 => 46206,
      3 => 46226,
      4 => 46246,
      5 => 46266,
      6 => 46286,
      7 => 46306,
      8 => 46326,
      9 => 46346,
    ),
    'MarkFilteringSet' => '',
  ),
  92 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 46548,
    ),
    'MarkFilteringSet' => '',
  ),
  93 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 46602,
      1 => 46622,
      2 => 46644,
      3 => 46666,
      4 => 46688,
    ),
    'MarkFilteringSet' => '',
  ),
  94 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 47114,
      1 => 47136,
    ),
    'MarkFilteringSet' => '',
  ),
  95 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47424,
    ),
    'MarkFilteringSet' => '',
  ),
  96 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47470,
    ),
    'MarkFilteringSet' => '',
  ),
  97 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 47592,
      1 => 47612,
    ),
    'MarkFilteringSet' => '',
  ),
  98 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47680,
    ),
    'MarkFilteringSet' => '',
  ),
  99 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47734,
    ),
    'MarkFilteringSet' => '',
  ),
  100 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47860,
    ),
    'MarkFilteringSet' => '',
  ),
  101 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47910,
    ),
    'MarkFilteringSet' => '',
  ),
  102 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47940,
    ),
    'MarkFilteringSet' => '',
  ),
  103 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47970,
    ),
    'MarkFilteringSet' => '',
  ),
  104 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48002,
    ),
    'MarkFilteringSet' => '',
  ),
  105 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48034,
    ),
    'MarkFilteringSet' => '',
  ),
  106 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48066,
    ),
    'MarkFilteringSet' => '',
  ),
  107 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48098,
    ),
    'MarkFilteringSet' => '',
  ),
  108 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48154,
    ),
    'MarkFilteringSet' => '',
  ),
  109 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48186,
    ),
    'MarkFilteringSet' => '',
  ),
  110 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48218,
    ),
    'MarkFilteringSet' => '',
  ),
  111 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48258,
    ),
    'MarkFilteringSet' => '',
  ),
  112 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48386,
    ),
    'MarkFilteringSet' => '',
  ),
  113 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48442,
    ),
    'MarkFilteringSet' => '',
  ),
  114 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48506,
    ),
    'MarkFilteringSet' => '',
  ),
  115 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48546,
    ),
    'MarkFilteringSet' => '',
  ),
  116 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48578,
    ),
    'MarkFilteringSet' => '',
  ),
  117 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48650,
    ),
    'MarkFilteringSet' => '',
  ),
  118 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48802,
    ),
    'MarkFilteringSet' => '',
  ),
  119 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48842,
    ),
    'MarkFilteringSet' => '',
  ),
  120 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48934,
    ),
    'MarkFilteringSet' => '',
  ),
  121 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48956,
    ),
    'MarkFilteringSet' => '',
  ),
  122 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48994,
    ),
    'MarkFilteringSet' => '',
  ),
  123 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 49022,
    ),
    'MarkFilteringSet' => '',
  ),
  124 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 49050,
    ),
    'MarkFilteringSet' => '',
  ),
  125 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 51300,
    ),
    'MarkFilteringSet' => '',
  ),
  126 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 51410,
    ),
    'MarkFilteringSet' => '',
  ),
  127 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 51520,
    ),
    'MarkFilteringSet' => '',
  ),
  128 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 53770,
    ),
    'MarkFilteringSet' => '',
  ),
  129 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 54898,
    ),
    'MarkFilteringSet' => '',
  ),
  130 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56026,
    ),
    'MarkFilteringSet' => '',
  ),
  131 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 58276,
    ),
    'MarkFilteringSet' => '',
  ),
  132 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 58302,
    ),
    'MarkFilteringSet' => '',
  ),
  133 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 58324,
    ),
    'MarkFilteringSet' => '',
  ),
  134 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 58350,
    ),
    'MarkFilteringSet' => '',
  ),
  135 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 59292,
    ),
    'MarkFilteringSet' => '',
  ),
  136 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 60234,
    ),
    'MarkFilteringSet' => '',
  ),
  137 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 61176,
    ),
    'MarkFilteringSet' => '',
  ),
  138 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 62526,
    ),
    'MarkFilteringSet' => '',
  ),
  139 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 62924,
    ),
    'MarkFilteringSet' => '',
  ),
  140 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64274,
    ),
    'MarkFilteringSet' => '',
  ),
  141 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64296,
    ),
    'MarkFilteringSet' => '',
  ),
  142 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64318,
    ),
    'MarkFilteringSet' => '',
  ),
  143 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64340,
    ),
    'MarkFilteringSet' => '',
  ),
  144 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64366,
    ),
    'MarkFilteringSet' => '',
  ),
  145 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64388,
    ),
    'MarkFilteringSet' => '',
  ),
  146 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64414,
    ),
    'MarkFilteringSet' => '',
  ),
  147 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64436,
    ),
    'MarkFilteringSet' => '',
  ),
  148 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64606,
    ),
    'MarkFilteringSet' => '',
  ),
  149 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64716,
    ),
    'MarkFilteringSet' => '',
  ),
  150 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64738,
    ),
    'MarkFilteringSet' => '',
  ),
  151 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64834,
    ),
    'MarkFilteringSet' => '',
  ),
  152 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64874,
    ),
    'MarkFilteringSet' => '',
  ),
  153 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64896,
    ),
    'MarkFilteringSet' => '',
  ),
  154 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64918,
    ),
    'MarkFilteringSet' => '',
  ),
  155 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64940,
    ),
    'MarkFilteringSet' => '',
  ),
  156 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64962,
    ),
    'MarkFilteringSet' => '',
  ),
  157 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 64984,
    ),
    'MarkFilteringSet' => '',
  ),
  158 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 65006,
    ),
    'MarkFilteringSet' => '',
  ),
  159 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 66578,
    ),
    'MarkFilteringSet' => '',
  ),
  160 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 67432,
    ),
    'MarkFilteringSet' => '',
  ),
  161 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 67464,
    ),
    'MarkFilteringSet' => '',
  ),
  162 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 67496,
    ),
    'MarkFilteringSet' => '',
  ),
  163 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 74396,
    ),
    'MarkFilteringSet' => '',
  ),
  164 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 76856,
    ),
    'MarkFilteringSet' => '',
  ),
  165 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 76896,
    ),
    'MarkFilteringSet' => '',
  ),
  166 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 80244,
    ),
    'MarkFilteringSet' => '',
  ),
  167 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 80602,
    ),
    'MarkFilteringSet' => '',
  ),
  168 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 85718,
    ),
    'MarkFilteringSet' => '',
  ),
  169 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 85774,
    ),
    'MarkFilteringSet' => '',
  ),
  170 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87338,
    ),
    'MarkFilteringSet' => '',
  ),
  171 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87376,
    ),
    'MarkFilteringSet' => '',
  ),
  172 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87994,
    ),
    'MarkFilteringSet' => '',
  ),
  173 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88012,
    ),
    'MarkFilteringSet' => '',
  ),
  174 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88030,
    ),
    'MarkFilteringSet' => '',
  ),
  175 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88048,
    ),
    'MarkFilteringSet' => '',
  ),
  176 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88062,
    ),
    'MarkFilteringSet' => '',
  ),
  177 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88080,
    ),
    'MarkFilteringSet' => '',
  ),
  178 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88098,
    ),
    'MarkFilteringSet' => '',
  ),
  179 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88116,
    ),
    'MarkFilteringSet' => '',
  ),
  180 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 90014,
    ),
    'MarkFilteringSet' => '',
  ),
  181 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 90038,
    ),
    'MarkFilteringSet' => '',
  ),
  182 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 90072,
    ),
    'MarkFilteringSet' => '',
  ),
  183 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 90152,
    ),
    'MarkFilteringSet' => '',
  ),
  184 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 90176,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'mymr' => 'DFLT KHT  KSW  KYU  dflt ',
);
$GPOSFeatures=array (
  'mymr' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 2,
        2 => 6,
      ),
      'mkmk' => 
      array (
        0 => 1,
        1 => 3,
        2 => 7,
      ),
      'kern' => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
        3 => 11,
        4 => 12,
        5 => 13,
        6 => 14,
        7 => 15,
        8 => 16,
        9 => 22,
        10 => 17,
        11 => 18,
        12 => 23,
        13 => 25,
        14 => 26,
        15 => 27,
        16 => 28,
      ),
    ),
    'KHT ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 2,
        2 => 6,
      ),
      'mkmk' => 
      array (
        0 => 1,
        1 => 3,
        2 => 7,
      ),
      'kern' => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
        3 => 11,
        4 => 12,
        5 => 13,
        6 => 14,
        7 => 15,
        8 => 16,
        9 => 22,
        10 => 17,
        11 => 18,
        12 => 23,
        13 => 25,
        14 => 26,
        15 => 28,
      ),
    ),
    'KSW ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 2,
        2 => 6,
      ),
      'mkmk' => 
      array (
        0 => 1,
        1 => 3,
        2 => 7,
      ),
      'kern' => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
        3 => 11,
        4 => 12,
        5 => 13,
        6 => 14,
        7 => 15,
        8 => 16,
        9 => 22,
        10 => 17,
        11 => 18,
        12 => 19,
        13 => 20,
        14 => 21,
        15 => 23,
        16 => 25,
        17 => 26,
        18 => 27,
        19 => 28,
      ),
    ),
    'KYU ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 2,
        2 => 6,
      ),
      'mkmk' => 
      array (
        0 => 1,
        1 => 3,
        2 => 7,
      ),
      'kern' => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
        3 => 11,
        4 => 12,
        5 => 13,
        6 => 14,
        7 => 15,
        8 => 16,
        9 => 22,
        10 => 17,
        11 => 18,
        12 => 23,
        13 => 25,
        14 => 26,
        15 => 27,
        16 => 28,
      ),
    ),
    'dflt' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 2,
        2 => 6,
      ),
      'mkmk' => 
      array (
        0 => 1,
        1 => 3,
        2 => 7,
      ),
      'kern' => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
        3 => 11,
        4 => 12,
        5 => 13,
        6 => 14,
        7 => 15,
        8 => 16,
        9 => 22,
        10 => 17,
        11 => 18,
        12 => 23,
        13 => 25,
        14 => 26,
        15 => 27,
        16 => 28,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 256,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 1924,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 6,
    'Flag' => 256,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 3396,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 512,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 3620,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 6,
    'Flag' => 512,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 5480,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 768,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 6286,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 6,
    'Flag' => 768,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 7698,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 1024,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 8186,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 6,
    'Flag' => 1024,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 9792,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 10214,
      1 => 10234,
      2 => 10254,
      3 => 10274,
      4 => 10294,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 10,
    'Subtables' => 
    array (
      0 => 10748,
      1 => 10768,
      2 => 10788,
      3 => 10808,
      4 => 10830,
      5 => 10852,
      6 => 10876,
      7 => 10896,
      8 => 10918,
      9 => 10938,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 11386,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 11664,
      1 => 11684,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 23,
    'Subtables' => 
    array (
      0 => 11784,
      1 => 11804,
      2 => 11824,
      3 => 11844,
      4 => 11862,
      5 => 11882,
      6 => 11902,
      7 => 11924,
      8 => 11946,
      9 => 11968,
      10 => 11990,
      11 => 12012,
      12 => 12032,
      13 => 12054,
      14 => 12074,
      15 => 12094,
      16 => 12116,
      17 => 12138,
      18 => 12158,
      19 => 12180,
      20 => 12200,
      21 => 12222,
      22 => 12240,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 12,
    'Subtables' => 
    array (
      0 => 12402,
      1 => 12422,
      2 => 12442,
      3 => 12462,
      4 => 12482,
      5 => 12502,
      6 => 12520,
      7 => 12540,
      8 => 12560,
      9 => 12582,
      10 => 12604,
      11 => 12626,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 42,
    'Subtables' => 
    array (
      0 => 12982,
      1 => 13006,
      2 => 13030,
      3 => 13054,
      4 => 13078,
      5 => 13102,
      6 => 13126,
      7 => 13146,
      8 => 13166,
      9 => 13186,
      10 => 13206,
      11 => 13226,
      12 => 13246,
      13 => 13266,
      14 => 13286,
      15 => 13306,
      16 => 13326,
      17 => 13346,
      18 => 13366,
      19 => 13388,
      20 => 13410,
      21 => 13432,
      22 => 13452,
      23 => 13472,
      24 => 13492,
      25 => 13512,
      26 => 13532,
      27 => 13552,
      28 => 13574,
      29 => 13596,
      30 => 13618,
      31 => 13638,
      32 => 13658,
      33 => 13678,
      34 => 13698,
      35 => 13718,
      36 => 13738,
      37 => 13760,
      38 => 13782,
      39 => 13804,
      40 => 13826,
      41 => 13848,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 22,
    'Subtables' => 
    array (
      0 => 14252,
      1 => 14272,
      2 => 14292,
      3 => 14312,
      4 => 14334,
      5 => 14356,
      6 => 14378,
      7 => 14400,
      8 => 14422,
      9 => 14444,
      10 => 14466,
      11 => 14488,
      12 => 14508,
      13 => 14528,
      14 => 14550,
      15 => 14572,
      16 => 14594,
      17 => 14616,
      18 => 14634,
      19 => 14654,
      20 => 14674,
      21 => 14694,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 6,
    'Subtables' => 
    array (
      0 => 15092,
      1 => 15110,
      2 => 15130,
      3 => 15150,
      4 => 15170,
      5 => 15190,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 15426,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 15472,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 15644,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 15686,
      1 => 15704,
      2 => 15722,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 15776,
      1 => 15794,
      2 => 15812,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 16,
    'Subtables' => 
    array (
      0 => 15892,
      1 => 15910,
      2 => 15928,
      3 => 15948,
      4 => 15968,
      5 => 15988,
      6 => 16008,
      7 => 16028,
      8 => 16048,
      9 => 16068,
      10 => 16088,
      11 => 16108,
      12 => 16128,
      13 => 16148,
      14 => 16166,
      15 => 16186,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 16444,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 16498,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 16764,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 16802,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 16856,
      1 => 16874,
    ),
    'MarkFilteringSet' => '',
  ),
  28 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 6,
    'Subtables' => 
    array (
      0 => 16928,
      1 => 16946,
      2 => 16964,
      3 => 16982,
      4 => 17000,
      5 => 17018,
    ),
    'MarkFilteringSet' => '',
  ),
  29 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17148,
    ),
    'MarkFilteringSet' => '',
  ),
  30 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17414,
    ),
    'MarkFilteringSet' => '',
  ),
  31 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17662,
    ),
    'MarkFilteringSet' => '',
  ),
  32 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17688,
    ),
    'MarkFilteringSet' => '',
  ),
  33 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17712,
    ),
    'MarkFilteringSet' => '',
  ),
  34 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17738,
    ),
    'MarkFilteringSet' => '',
  ),
  35 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 17768,
      1 => 17840,
      2 => 17852,
    ),
    'MarkFilteringSet' => '',
  ),
  36 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17920,
    ),
    'MarkFilteringSet' => '',
  ),
  37 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17946,
    ),
    'MarkFilteringSet' => '',
  ),
  38 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17972,
    ),
    'MarkFilteringSet' => '',
  ),
  39 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 17998,
    ),
    'MarkFilteringSet' => '',
  ),
  40 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 18024,
    ),
    'MarkFilteringSet' => '',
  ),
  41 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 18048,
    ),
    'MarkFilteringSet' => '',
  ),
  42 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 18072,
    ),
    'MarkFilteringSet' => '',
  ),
  43 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 18096,
    ),
    'MarkFilteringSet' => '',
  ),
  44 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 18120,
    ),
    'MarkFilteringSet' => '',
  ),
  45 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 18146,
    ),
    'MarkFilteringSet' => '',
  ),
  46 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 18170,
    ),
    'MarkFilteringSet' => '',
  ),
  47 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 18224,
      1 => 18234,
    ),
    'MarkFilteringSet' => '',
  ),
  48 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 18266,
      1 => 18426,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>