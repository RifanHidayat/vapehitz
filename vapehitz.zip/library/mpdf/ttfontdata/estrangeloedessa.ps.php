<?php 
$originalsize=60428;
?>