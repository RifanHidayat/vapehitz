<?php
$name='Ayar';
$type='TTF';
$desc=array (
  'CapHeight' => 995,
  'XHeight' => 554,
  'FontBBox' => '[-1084 -513 2461 1022]',
  'Flags' => 4,
  'Ascent' => 1022,
  'Descent' => -464,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 290,
);
$unitsPerEm=2048;
$up=-464;
$ut=63;
$strp=336;
$strs=63;
$ttffile='D:/webroot/sidd/mpdf/ttfonts/ayar.ttf';
$TTCfontID='0';
$originalsize=282664;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='ayar';
$panose=' 8 0 2 b 6 4 3 5 4 4 2 4';
$haskerninfo=true;
$haskernGPOS=true;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1055, -464, 49
// usWinAscent/usWinDescent = 1055, -464
// hhea Ascent/Descent/LineGap = 1055, -464, 49
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'mymr' => 'DFLT ',
);
$GSUBFeatures=array (
  'mymr' => 
  array (
    'DFLT' => 
    array (
      'liga' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
        11 => 11,
        12 => 12,
        13 => 13,
        14 => 14,
        15 => 15,
        16 => 16,
        17 => 17,
        18 => 18,
        19 => 19,
        20 => 20,
        21 => 21,
        22 => 22,
        23 => 23,
        24 => 24,
        25 => 25,
        26 => 26,
        27 => 27,
        28 => 28,
        29 => 29,
        30 => 30,
        31 => 31,
        32 => 32,
        33 => 33,
        34 => 34,
        35 => 35,
        36 => 36,
        37 => 37,
        38 => 38,
        39 => 39,
        40 => 40,
        41 => 41,
        42 => 42,
        43 => 43,
        44 => 44,
        45 => 45,
        46 => 46,
        47 => 47,
        48 => 48,
        49 => 49,
      ),
      'kern' => 
      array (
        0 => 44,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 248454,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 248956,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 249576,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 249606,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 249766,
      1 => 249786,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 250104,
      1 => 250124,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 250358,
      1 => 250378,
      2 => 250400,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 251034,
      1 => 251054,
      2 => 251076,
      3 => 251100,
      4 => 251124,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 252044,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 252304,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 6,
    'Subtables' => 
    array (
      0 => 252522,
      1 => 252542,
      2 => 252562,
      3 => 252584,
      4 => 252606,
      5 => 252628,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 253630,
      1 => 253650,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 254172,
      1 => 254192,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 254630,
      1 => 254648,
      2 => 254666,
      3 => 254686,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 255242,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 255272,
      1 => 255292,
      2 => 255310,
      3 => 255330,
      4 => 255350,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 12,
    'Subtables' => 
    array (
      0 => 255460,
      1 => 255478,
      2 => 255496,
      3 => 255516,
      4 => 255534,
      5 => 255554,
      6 => 255572,
      7 => 255592,
      8 => 255610,
      9 => 255632,
      10 => 255654,
      11 => 255676,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 256830,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 27,
    'Subtables' => 
    array (
      0 => 256986,
      1 => 257004,
      2 => 257024,
      3 => 257044,
      4 => 257066,
      5 => 257086,
      6 => 257108,
      7 => 257130,
      8 => 257152,
      9 => 257174,
      10 => 257196,
      11 => 257218,
      12 => 257240,
      13 => 257262,
      14 => 257282,
      15 => 257304,
      16 => 257324,
      17 => 257342,
      18 => 257362,
      19 => 257382,
      20 => 257402,
      21 => 257424,
      22 => 257446,
      23 => 257468,
      24 => 257490,
      25 => 257514,
      26 => 257538,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 8,
    'Subtables' => 
    array (
      0 => 261332,
      1 => 261352,
      2 => 261370,
      3 => 261390,
      4 => 261410,
      5 => 261430,
      6 => 261448,
      7 => 261468,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 11,
    'Subtables' => 
    array (
      0 => 261588,
      1 => 261610,
      2 => 261632,
      3 => 261654,
      4 => 261676,
      5 => 261694,
      6 => 261714,
      7 => 261732,
      8 => 261752,
      9 => 261772,
      10 => 261794,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 263660,
      1 => 263680,
      2 => 263700,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 8,
    'Subtables' => 
    array (
      0 => 264366,
      1 => 264390,
      2 => 264414,
      3 => 264438,
      4 => 264462,
      5 => 264486,
      6 => 264510,
      7 => 264534,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 11,
    'Subtables' => 
    array (
      0 => 266036,
      1 => 266054,
      2 => 266074,
      3 => 266094,
      4 => 266114,
      5 => 266132,
      6 => 266152,
      7 => 266172,
      8 => 266194,
      9 => 266216,
      10 => 266236,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 266576,
      1 => 266594,
      2 => 266614,
      3 => 266634,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 267160,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 6,
    'Subtables' => 
    array (
      0 => 267192,
      1 => 267212,
      2 => 267232,
      3 => 267252,
      4 => 267272,
      5 => 267292,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 267390,
      1 => 267408,
      2 => 267428,
    ),
    'MarkFilteringSet' => '',
  ),
  28 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 7,
    'Subtables' => 
    array (
      0 => 267704,
      1 => 267724,
      2 => 267742,
      3 => 267762,
      4 => 267784,
      5 => 267804,
      6 => 267826,
    ),
    'MarkFilteringSet' => '',
  ),
  29 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 268828,
    ),
    'MarkFilteringSet' => '',
  ),
  30 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 268852,
    ),
    'MarkFilteringSet' => '',
  ),
  31 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 269076,
      1 => 269094,
      2 => 269114,
      3 => 269136,
    ),
    'MarkFilteringSet' => '',
  ),
  32 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 269746,
      1 => 269766,
    ),
    'MarkFilteringSet' => '',
  ),
  33 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 269816,
    ),
    'MarkFilteringSet' => '',
  ),
  34 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 269846,
    ),
    'MarkFilteringSet' => '',
  ),
  35 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 269876,
    ),
    'MarkFilteringSet' => '',
  ),
  36 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 269906,
      1 => 269924,
      2 => 269944,
      3 => 269966,
    ),
    'MarkFilteringSet' => '',
  ),
  37 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 270576,
    ),
    'MarkFilteringSet' => '',
  ),
  38 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 270610,
    ),
    'MarkFilteringSet' => '',
  ),
  39 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 270966,
    ),
    'MarkFilteringSet' => '',
  ),
  40 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 271280,
    ),
    'MarkFilteringSet' => '',
  ),
  41 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 271306,
    ),
    'MarkFilteringSet' => '',
  ),
  42 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 271618,
    ),
    'MarkFilteringSet' => '',
  ),
  43 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 271930,
    ),
    'MarkFilteringSet' => '',
  ),
  44 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 10,
    'Subtables' => 
    array (
      0 => 271976,
      1 => 271998,
      2 => 272020,
      3 => 272042,
      4 => 272064,
      5 => 272086,
      6 => 272110,
      7 => 272134,
      8 => 272158,
      9 => 272180,
    ),
    'MarkFilteringSet' => '',
  ),
  45 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 273992,
    ),
    'MarkFilteringSet' => '',
  ),
  46 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 274286,
    ),
    'MarkFilteringSet' => '',
  ),
  47 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 274320,
    ),
    'MarkFilteringSet' => '',
  ),
  48 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 274562,
    ),
    'MarkFilteringSet' => '',
  ),
  49 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 274906,
      1 => 274928,
      2 => 274952,
      3 => 274976,
    ),
    'MarkFilteringSet' => '',
  ),
  50 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275508,
    ),
    'MarkFilteringSet' => '',
  ),
  51 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275780,
    ),
    'MarkFilteringSet' => '',
  ),
  52 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275794,
    ),
    'MarkFilteringSet' => '',
  ),
  53 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275808,
    ),
    'MarkFilteringSet' => '',
  ),
  54 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275822,
    ),
    'MarkFilteringSet' => '',
  ),
  55 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275836,
    ),
    'MarkFilteringSet' => '',
  ),
  56 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275850,
    ),
    'MarkFilteringSet' => '',
  ),
  57 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275864,
    ),
    'MarkFilteringSet' => '',
  ),
  58 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275882,
    ),
    'MarkFilteringSet' => '',
  ),
  59 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275900,
    ),
    'MarkFilteringSet' => '',
  ),
  60 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275914,
    ),
    'MarkFilteringSet' => '',
  ),
  61 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275928,
    ),
    'MarkFilteringSet' => '',
  ),
  62 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275942,
    ),
    'MarkFilteringSet' => '',
  ),
  63 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275956,
    ),
    'MarkFilteringSet' => '',
  ),
  64 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275970,
    ),
    'MarkFilteringSet' => '',
  ),
  65 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275984,
    ),
    'MarkFilteringSet' => '',
  ),
  66 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 275998,
    ),
    'MarkFilteringSet' => '',
  ),
  67 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276016,
    ),
    'MarkFilteringSet' => '',
  ),
  68 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276030,
    ),
    'MarkFilteringSet' => '',
  ),
  69 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276044,
    ),
    'MarkFilteringSet' => '',
  ),
  70 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276058,
    ),
    'MarkFilteringSet' => '',
  ),
  71 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276072,
    ),
    'MarkFilteringSet' => '',
  ),
  72 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276086,
    ),
    'MarkFilteringSet' => '',
  ),
  73 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276100,
    ),
    'MarkFilteringSet' => '',
  ),
  74 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276114,
    ),
    'MarkFilteringSet' => '',
  ),
  75 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276128,
    ),
    'MarkFilteringSet' => '',
  ),
  76 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276142,
    ),
    'MarkFilteringSet' => '',
  ),
  77 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276156,
    ),
    'MarkFilteringSet' => '',
  ),
  78 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276170,
    ),
    'MarkFilteringSet' => '',
  ),
  79 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276276,
    ),
    'MarkFilteringSet' => '',
  ),
  80 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276310,
    ),
    'MarkFilteringSet' => '',
  ),
  81 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276324,
    ),
    'MarkFilteringSet' => '',
  ),
  82 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276338,
    ),
    'MarkFilteringSet' => '',
  ),
  83 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276352,
    ),
    'MarkFilteringSet' => '',
  ),
  84 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276366,
    ),
    'MarkFilteringSet' => '',
  ),
  85 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276400,
    ),
    'MarkFilteringSet' => '',
  ),
  86 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276522,
    ),
    'MarkFilteringSet' => '',
  ),
  87 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276560,
    ),
    'MarkFilteringSet' => '',
  ),
  88 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276584,
    ),
    'MarkFilteringSet' => '',
  ),
  89 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276608,
    ),
    'MarkFilteringSet' => '',
  ),
  90 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276622,
    ),
    'MarkFilteringSet' => '',
  ),
  91 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276636,
    ),
    'MarkFilteringSet' => '',
  ),
  92 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276660,
    ),
    'MarkFilteringSet' => '',
  ),
  93 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276678,
    ),
    'MarkFilteringSet' => '',
  ),
  94 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276712,
    ),
    'MarkFilteringSet' => '',
  ),
  95 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 276784,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'mymr' => 'DFLT ',
);
$GPOSFeatures=array (
  'mymr' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 5,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 246588,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 246668,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 246700,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 246776,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 246866,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 246896,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 246934,
    ),
    'MarkFilteringSet' => '',
  ),
);
$kerninfo=array (
  57362 => 
  array (
    4140 => -85,
  ),
  4100 => 
  array (
    4141 => 29,
    4142 => 29,
    4143 => 24,
    4150 => 48,
    4154 => 19,
  ),
  57387 => 
  array (
    4140 => -65,
  ),
  57388 => 
  array (
    4140 => -117,
    4141 => -125,
  ),
  4114 => 
  array (
    4141 => 21,
    4142 => 21,
    4150 => 24,
    4154 => 19,
  ),
  57394 => 
  array (
    4140 => -23,
  ),
  57395 => 
  array (
    57389 => 219,
  ),
  57399 => 
  array (
    4140 => -117,
  ),
  57401 => 
  array (
    4140 => -7,
  ),
  57415 => 
  array (
    57360 => 97,
    57361 => 146,
    4134 => 183,
    4137 => 263,
    4156 => 263,
    57430 => 263,
    57431 => 263,
    57432 => 263,
    57433 => 263,
    57434 => 263,
    57435 => 263,
    57436 => 263,
    57437 => 263,
    57438 => 263,
    4166 => 183,
    4172 => 183,
  ),
  4141 => 
  array (
    57422 => 97,
  ),
  57420 => 
  array (
    57422 => 97,
  ),
  4194 => 
  array (
    4154 => 134,
  ),
  4210 => 
  array (
    57422 => 97,
  ),
  4218 => 
  array (
    4157 => 85,
  ),
  4222 => 
  array (
    4184 => 203,
    4226 => 222,
    57453 => 230,
    57457 => 70,
  ),
  4225 => 
  array (
    4143 => 36,
    4144 => 75,
    4157 => 129,
    4184 => 93,
    4226 => 129,
    57453 => 144,
  ),
);
?>