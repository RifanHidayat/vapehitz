<?php
$name='AboriginalSans';
$type='TTF';
$desc=array (
  'CapHeight' => 711,
  'XHeight' => 503,
  'FontBBox' => '[-737 -489 1786 1067]',
  'Flags' => 4,
  'Ascent' => 1054,
  'Descent' => -489,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 457,
);
$unitsPerEm=1000;
$up=-37;
$ut=24;
$strp=250;
$strs=50;
$ttffile='D:/webroot/sidd/mpdf/ttfonts/AboriginalSansREGULAR.ttf';
$TTCfontID='0';
$originalsize=800480;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='aboriginalsans';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 696, -226, 20
// usWinAscent/usWinDescent = 1054, -492
// hhea Ascent/Descent/LineGap = 1054, -492, 20
$useOTL=0x0000;
$rtlPUAstr='';
?>