<?php
$name='Jomolhari';
$type='TTF';
$desc=array (
  'CapHeight' => 738,
  'XHeight' => 352,
  'FontBBox' => '[-600 -596 1938 1271]',
  'Flags' => 4,
  'Ascent' => 1219,
  'Descent' => -383,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 703,
);
$unitsPerEm=1024;
$up=-275;
$ut=35;
$strp=250;
$strs=50;
$ttffile='D:/webroot/sidd/mpdf/ttfonts/Jomolhari.ttf';
$TTCfontID='0';
$originalsize=2269108;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='jomolhari';
$panose=' 0 0 1 1 1 0 1 1 1 1 1 1';
$haskerninfo=true;
$haskernGPOS=true;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1219, -383, 0
// usWinAscent/usWinDescent = 1219, -383
// hhea Ascent/Descent/LineGap = 1219, -383, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'tibt' => 'DFLT ',
);
$GSUBFeatures=array (
  'tibt' => 
  array (
    'DFLT' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'blws' => 
      array (
        0 => 2,
        1 => 3,
        2 => 4,
        3 => 5,
        4 => 6,
        5 => 7,
      ),
      'abvs' => 
      array (
        0 => 8,
        1 => 9,
        2 => 10,
        3 => 11,
        4 => 12,
        5 => 13,
        6 => 14,
        7 => 15,
        8 => 16,
        9 => 17,
      ),
      'calt' => 
      array (
        0 => 18,
        1 => 19,
        2 => 20,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2198872,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2198952,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2199358,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2207330,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2207344,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2212766,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2216538,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2218242,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2218376,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2218964,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2223202,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2226088,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2227152,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2230136,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2230812,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2232550,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2236384,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2236754,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2239036,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2239116,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2239156,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2239472,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2239558,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2239616,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2239630,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'tibt' => 'DFLT ',
);
$GPOSFeatures=array (
  'tibt' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2197500,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 2198286,
    ),
    'MarkFilteringSet' => '',
  ),
);
$kerninfo=array (
  3851 => 
  array (
    3904 => -5,
    62213 => -5,
    62214 => -5,
    62994 => -5,
    62216 => -5,
    62217 => -5,
    62999 => -5,
    62218 => -5,
    63000 => -5,
    63001 => -5,
    62215 => -5,
    62998 => -5,
    63002 => -5,
    62237 => -5,
    63038 => -5,
    63039 => -5,
    63040 => -5,
    3909 => -46,
    62390 => -46,
    62391 => -46,
    62393 => -46,
    62394 => -46,
    62395 => -46,
    62396 => -46,
    62397 => -46,
    62392 => -46,
  ),
  3852 => 
  array (
    3904 => -5,
    62213 => -5,
    62214 => -5,
    62994 => -5,
    62216 => -5,
    62217 => -5,
    62999 => -5,
    62218 => -5,
    63000 => -5,
    63001 => -5,
    62215 => -5,
    62998 => -5,
    63002 => -5,
    62237 => -5,
    63038 => -5,
    63039 => -5,
    63040 => -5,
    3909 => -46,
    62390 => -46,
    62391 => -46,
    62393 => -46,
    62394 => -46,
    62395 => -46,
    62396 => -46,
    62397 => -46,
    62392 => -46,
  ),
  3908 => 
  array (
    3851 => -78,
    3852 => -78,
  ),
  62366 => 
  array (
    3851 => -78,
    3852 => -78,
  ),
  62367 => 
  array (
    3851 => -78,
    3852 => -78,
  ),
  62369 => 
  array (
    3851 => -78,
    3852 => -78,
  ),
  62370 => 
  array (
    3851 => -78,
    3852 => -78,
  ),
  62371 => 
  array (
    3851 => -78,
    3852 => -78,
  ),
  62368 => 
  array (
    3851 => -78,
    3852 => -78,
  ),
  63122 => 
  array (
    3851 => -99,
    3852 => -99,
  ),
  3909 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62390 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62391 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62393 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62394 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62395 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62396 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62397 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62392 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  3910 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62409 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62410 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62413 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62414 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62415 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62417 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62412 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  3913 => 
  array (
    3851 => -101,
    3852 => -101,
  ),
  62445 => 
  array (
    3851 => -101,
    3852 => -101,
  ),
  62448 => 
  array (
    3851 => -101,
    3852 => -101,
  ),
  62449 => 
  array (
    3851 => -101,
    3852 => -101,
  ),
  62446 => 
  array (
    3851 => -101,
    3852 => -101,
  ),
  62450 => 
  array (
    3851 => -101,
    3852 => -101,
  ),
  3919 => 
  array (
    3851 => -41,
    3852 => -41,
  ),
  62494 => 
  array (
    3851 => -41,
    3852 => -41,
  ),
  62497 => 
  array (
    3851 => -41,
    3852 => -41,
  ),
  62498 => 
  array (
    3851 => -41,
    3852 => -41,
  ),
  62495 => 
  array (
    3851 => -41,
    3852 => -41,
  ),
  3921 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62535 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62536 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62539 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62540 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62537 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62548 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62549 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62552 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62553 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  62550 => 
  array (
    3851 => -82,
    3852 => -82,
  ),
  3923 => 
  array (
    3851 => -29,
    3852 => -29,
  ),
  62578 => 
  array (
    3851 => -29,
    3852 => -29,
  ),
  62579 => 
  array (
    3851 => -29,
    3852 => -29,
  ),
  62581 => 
  array (
    3851 => -29,
    3852 => -29,
  ),
  62582 => 
  array (
    3851 => -29,
    3852 => -29,
  ),
  62583 => 
  array (
    3851 => -29,
    3852 => -29,
  ),
  62580 => 
  array (
    3851 => -29,
    3852 => -29,
  ),
  3933 => 
  array (
    3851 => 23,
    3852 => 23,
  ),
  62821 => 
  array (
    3851 => 23,
    3852 => 23,
  ),
  62822 => 
  array (
    3851 => 23,
    3852 => 23,
  ),
  62824 => 
  array (
    3851 => 23,
    3852 => 23,
  ),
  62825 => 
  array (
    3851 => 23,
    3852 => 23,
  ),
  62826 => 
  array (
    3851 => 23,
    3852 => 23,
  ),
  62823 => 
  array (
    3851 => 23,
    3852 => 23,
  ),
  3936 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  62865 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  58182 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  62868 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  62870 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  62871 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  62873 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  62872 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  62878 => 
  array (
    3851 => -39,
    3852 => -39,
  ),
  3938 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62889 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62890 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62891 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62892 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  62238 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62239 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62241 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62242 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62243 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62240 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  58220 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62244 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62245 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62247 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62248 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62249 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62246 => 
  array (
    3851 => -70,
    3852 => -70,
  ),
  62747 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62748 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62750 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62751 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62752 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62749 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62753 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62754 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62756 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62757 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62758 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62755 => 
  array (
    3851 => -140,
    3852 => -140,
  ),
  62783 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62784 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62786 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62787 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62788 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62785 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62789 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  58264 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  63548 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62809 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62810 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62812 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62813 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62814 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62811 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  58265 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  63550 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  63549 => 
  array (
    3851 => 52,
    3852 => 52,
  ),
  62900 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
  3946 => 
  array (
    3851 => -58,
    3852 => -58,
  ),
);
?>