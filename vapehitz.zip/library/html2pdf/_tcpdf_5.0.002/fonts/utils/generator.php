<?php
require('makefont.php');

MakeFont('c:\\Windows\\Fonts\\Tahoma.ttf','cp1252');
?>